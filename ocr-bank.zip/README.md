# OCR для банковских документов (MVP)

## 🚀 Возможности
- Распознавание текста с банковских документов (чеки, выписки, договора)
- Vision Transformers (Donut) + OCR (PaddleOCR) для сложных случаев
- Постобработка через LLM (пока заглушка)
- Вывод в формате JSON

## 📂 Структура проекта
- models/ — модели Donut и PaddleOCR
- app/ — основной пайплайн + схема данных
- demo/ — Streamlit веб-приложение
- data/ — тестовые изображения

## ▶️ Запуск
1. Установи зависимости:
   ```bash
   pip install paddleocr paddlepaddle torch torchvision transformers streamlit pillow
   ```

2. Запусти демо:
   ```bash
   streamlit run demo/app.py
   ```

3. Загрузи JPG/PNG скан → получи JSON.

## 🔮 Дальнейшие шаги
- Подключить LLM (например GPT/LLaMA) для выделения ключевых полей.
- Добавить поддержку PDF (pdf2image).
- Обучить Vision Transformer под банковские документы.
